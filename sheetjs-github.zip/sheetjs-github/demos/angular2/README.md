# Angular 2+

[The new demo](https://docs.sheetjs.com/docs/demos/angular) has an updated
exposition for legacy and modern deployments alike.

The ecosystem demos were grouped by type in the new demo site:

- [NativeScript](https://docs.sheetjs.com/docs/demos/mobile#nativescript) is now part of "iOS and Android Apps"
- [Ionic](https://docs.sheetjs.com/docs/demos/mobile#ionic) is now part of "iOS and Android Apps"

[![Analytics](https://ga-beacon.appspot.com/UA-36810333-1/SheetJS/js-xlsx?pixel)](https://github.com/SheetJS/js-xlsx)
