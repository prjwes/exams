# Chrome and Chromium

[The new demo](https://docs.sheetjs.com/docs/demos/chromium)
includes more up-to-date details.

[![Analytics](https://ga-beacon.appspot.com/UA-36810333-1/SheetJS/js-xlsx?pixel)](https://github.com/SheetJS/js-xlsx)
