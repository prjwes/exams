# Parcel

[The new demo](https://docs.sheetjs.com/docs/demos/bundler#parcel)
includes a more concise example.

[![Analytics](https://ga-beacon.appspot.com/UA-36810333-1/SheetJS/js-xlsx?pixel)](https://github.com/SheetJS/js-xlsx)
